package com.awesomeevents.controllers;

import java.util.List;

import com.awesomeevents.model.Player;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.awesomeevents.service.PlayerService;

@Controller
public class PlayerController {

	@Autowired
    PlayerService playerService;

	@RequestMapping("/welcome")
	public ModelAndView firstPage() {
		return new ModelAndView("welcome");
	}

	@RequestMapping(value = "/addNewPlayer", method = RequestMethod.GET)
	public ModelAndView show() {
		return new ModelAndView("addPlayer", "player", new Player());
	}

	@RequestMapping(value = "/addNewPlayer", method = RequestMethod.POST)
	public ModelAndView processRequest(@ModelAttribute("player") Player player) {
		
		playerService.insertPlayer(player);
		List<Player> players = playerService.getAllPlayers();
		ModelAndView model = new ModelAndView("getPlayers");
		model.addObject("players", players);
		return model;
	}

	@RequestMapping("/getPlayers")
	public ModelAndView getPlayers() {
		List<Player> players = playerService.getAllPlayers();
		ModelAndView model = new ModelAndView("getPlayers");
		model.addObject("players", players);
		return model;
	}

	@RequestMapping("/prepareReport")
	public ModelAndView getReport() {
		List<Player> players = playerService.getAllPlayers();
		for(int i=0;i<players.size();i++)
		{
			players.get(i).setGame(i%2==0?"Carroms":"Chess");
		}
		ModelAndView model = new ModelAndView("report");
		model.addObject("players", players);
		return model;
	}


}
