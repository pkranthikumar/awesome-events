package com.awesomeevents.service.impl;

import java.util.List;

import com.awesomeevents.model.Player;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.awesomeevents.dao.PlayerDao;
import com.awesomeevents.service.PlayerService;

@Service
public class PlayerServiceImpl implements PlayerService {

	@Autowired
	PlayerDao playerDao;

	@Override
	public void insertPlayer(Player player) {
		playerDao.insertPlayer(player);
	}

	@Override
	public void insertPlayers(List<Player> players) {
		playerDao.insertPlayers(players);
	}

	public List<Player> getAllPlayers() {
		return playerDao.getAllPlayers();
	}

	@Override
	public void getPlayerById(String email) {
		Player player = playerDao.getPlayerById(email);
		System.out.println(player);
	}

}