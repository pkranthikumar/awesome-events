package com.awesomeevents.service;

import java.util.List;

import com.awesomeevents.model.Player;

public interface PlayerService {
	void insertPlayer(Player player);
	void insertPlayers(List<Player> players);
	List<Player> getAllPlayers();
	void getPlayerById(String email);
}