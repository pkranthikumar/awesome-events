package com.awesomeevents.dao;

import java.util.List;

import com.awesomeevents.model.Player;

public interface PlayerDao {
	void insertPlayer(Player player);
	void insertPlayers(List<Player> players);
	List<Player> getAllPlayers();
	Player getPlayerById(String email);
}