package com.awesomeevents.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import com.awesomeevents.model.Player;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Repository;

import com.awesomeevents.dao.PlayerDao;

@Repository
public class PlayerDaoImpl extends JdbcDaoSupport implements PlayerDao {
	
	@Autowired 
	DataSource dataSource;
	
	@PostConstruct
	private void initialize(){
		setDataSource(dataSource);
	}
	
	@Override
	public void insertPlayer(Player player) {
		String sql = "INSERT INTO players " +
				"(email,firstname, lastname,dob) VALUES (?, ?,?,?)" ;
		getJdbcTemplate().update(sql, new Object[]{
				player.getEmail(), player.getFirstName(),player.getLastName(),player.getDob()
		});
	}
	
	@Override
	public void insertPlayers(final List<Player> players) {
		String sql = "INSERT INTO players " +
				"(email,firstname, lastname,dob) VALUES (?, ?,?,?)" ;
		getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				Player player = players.get(i);
				ps.setString(1, player.getEmail());
				ps.setString(2, player.getFirstName());
				ps.setString(3, player.getLastName());
				ps.setString(4, player.getDob());
			}
			
			public int getBatchSize() {
				return players.size();
			}
		});

	}
	@Override
	public List<Player> getAllPlayers(){
		String sql = "SELECT * FROM players";
		List<Player> players = getJdbcTemplate().query(sql, new RowMapper<Player>() {
			@Nullable
			@Override
			public Player mapRow(ResultSet rs, int rowNum) throws SQLException {
				 Player player = new Player();
				 player.setEmail(rs.getString("email"));
				player.setFirstName(rs.getString("firstname"));
				player.setLastName(rs.getString("lastname"));
				player.setDob(rs.getString("dob"));
				return player;
			}
		});

		return players;
	}

	@Override
	public Player getPlayerById(String email) {
		String sql = "SELECT * FROM players WHERE email = ?";

		Player player = getJdbcTemplate().queryForObject(sql, new RowMapper<Player>() {
			@Nullable
			@Override
			public Player mapRow(ResultSet rs, int rowNum) throws SQLException {
				Player player = new Player();
				player.setEmail(rs.getString("email"));
				player.setFirstName(rs.getString("firstname"));
				player.setLastName(rs.getString("lastname"));
				player.setDob(rs.getString("dob"));
				return player;
			}
		});
		return player;

	}
}